# Callback Exercises

Complete each of the exercises in order, executing them with `node` as you.

For example, complete the exercise in file `01.js`, then execute it:

```
$ node 01.js
```

If you have any questions or get stuck, your instructors are there to help!
